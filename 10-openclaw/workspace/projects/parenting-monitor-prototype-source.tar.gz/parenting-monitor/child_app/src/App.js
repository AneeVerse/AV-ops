import React, { useEffect, useState } from 'react';
import { Alert, SafeAreaView, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as Location from 'expo-location';
import * as Device from 'expo-device';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { FAMILY_ID, supabase } from './supabase';

async function getDeviceId() {
  let id = await AsyncStorage.getItem('device_id');
  if (!id) {
    id = `child-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    await AsyncStorage.setItem('device_id', id);
  }
  return id;
}

export default function App() {
  const [status, setStatus] = useState('Starting...');
  const [deviceName, setDeviceName] = useState(Device.deviceName || 'Child device');
  const [lastSent, setLastSent] = useState(null);

  useEffect(() => {
    let sub;
    let heartbeat;

    (async () => {
      const deviceId = await getDeviceId();
      const name = Device.deviceName || Device.modelName || 'Child device';
      setDeviceName(name);

      const { error: deviceError } = await supabase.from('devices').upsert({
        id: deviceId,
        family_id: FAMILY_ID,
        name,
        platform: Device.osName || 'unknown',
        last_seen: new Date().toISOString()
      });
      if (deviceError) {
        setStatus(`Backend error: ${deviceError.message}`);
        return;
      }

      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== 'granted') {
        setStatus('Location permission denied');
        Alert.alert('Permission required', 'Enable location permission to test live location.');
        return;
      }

      setStatus('Location sharing active');
      heartbeat = setInterval(() => {
        supabase.from('devices').update({ last_seen: new Date().toISOString() }).eq('id', deviceId);
      }, 10000);

      sub = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, timeInterval: 5000, distanceInterval: 5 },
        async (pos) => {
          const payload = {
            device_id: deviceId,
            family_id: FAMILY_ID,
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            speed: pos.coords.speed,
            heading: pos.coords.heading,
            recorded_at: new Date().toISOString()
          };
          await supabase.from('device_locations').insert(payload);
          await supabase.from('devices').update({ last_seen: new Date().toISOString() }).eq('id', deviceId);
          setLastSent(payload.recorded_at);
        }
      );
    })();

    return () => {
      if (sub) sub.remove();
      if (heartbeat) clearInterval(heartbeat);
    };
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="light" />
      <View style={styles.card}>
        <Text style={styles.title}>Child Device</Text>
        <Text style={styles.name}>{deviceName}</Text>
        <Text style={styles.status}>● {status}</Text>
        <Text style={styles.small}>Connected family: {FAMILY_ID}</Text>
        <Text style={styles.small}>{lastSent ? `Last location sent: ${new Date(lastSent).toLocaleTimeString()}` : 'Waiting for first location...'}</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#111827', alignItems: 'center', justifyContent: 'center', padding: 22 },
  card: { backgroundColor: '#1f2937', padding: 24, borderRadius: 20, width: '100%' },
  title: { color: 'white', fontSize: 28, fontWeight: '800' },
  name: { color: '#d1d5db', fontSize: 18, marginTop: 8 },
  status: { color: '#22c55e', fontSize: 16, marginTop: 22, fontWeight: '700' },
  small: { color: '#9ca3af', marginTop: 12 }
});
