create table if not exists public.devices (
  id text primary key,
  family_id text not null,
  name text not null,
  platform text,
  last_seen timestamptz default now(),
  created_at timestamptz default now()
);

create table if not exists public.device_locations (
  id bigint generated always as identity primary key,
  device_id text references public.devices(id) on delete cascade,
  family_id text not null,
  latitude double precision not null,
  longitude double precision not null,
  accuracy double precision,
  speed double precision,
  heading double precision,
  recorded_at timestamptz default now()
);

create index if not exists device_locations_device_time_idx
on public.device_locations(device_id, recorded_at desc);

alter table public.devices enable row level security;
alter table public.device_locations enable row level security;

-- Prototype-only open policies. Tighten before production.
drop policy if exists "prototype read devices" on public.devices;
drop policy if exists "prototype write devices" on public.devices;
drop policy if exists "prototype read locations" on public.device_locations;
drop policy if exists "prototype write locations" on public.device_locations;

create policy "prototype read devices" on public.devices for select using (true);
create policy "prototype write devices" on public.devices for all using (true) with check (true);
create policy "prototype read locations" on public.device_locations for select using (true);
create policy "prototype write locations" on public.device_locations for insert with check (true);
