# Parenting Monitor Prototype

Two Expo apps:

- `parent_app` — parent dashboard: device list, rename device, map view.
- `child_app` — minimal visible child client: requests location permission and sends live location.

This prototype uses Supabase for shared state. Create a Supabase project, run `supabase/schema.sql`, then add your Supabase URL/key in each app `.env`.

## Run

```bash
cd parent_app
npm install
cp .env.example .env
npm start
```

```bash
cd child_app
npm install
cp .env.example .env
npm start
```

Use Expo Go on two Android phones, or emulators.

## Safety note

The child app intentionally has a visible screen and asks OS location permission. Hidden tracking / silent audio is not implemented.
