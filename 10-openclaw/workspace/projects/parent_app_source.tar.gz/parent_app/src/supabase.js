import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';

export const FAMILY_ID = process.env.EXPO_PUBLIC_FAMILY_ID || 'demo-family-001';
export const supabase = createClient(
  process.env.EXPO_PUBLIC_SUPABASE_URL || '',
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || ''
);
