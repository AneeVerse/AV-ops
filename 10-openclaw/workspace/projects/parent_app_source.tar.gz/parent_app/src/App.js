import React, { useCallback, useEffect, useState } from 'react';
import { Alert, FlatList, Modal, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { StatusBar } from 'expo-status-bar';
import { FAMILY_ID, supabase } from './supabase';

const isLive = (lastSeen) => lastSeen && Date.now() - new Date(lastSeen).getTime() < 60_000;

export default function App() {
  const [devices, setDevices] = useState([]);
  const [locations, setLocations] = useState({});
  const [selected, setSelected] = useState(null);
  const [renameOpen, setRenameOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: devs, error } = await supabase
      .from('devices')
      .select('*')
      .eq('family_id', FAMILY_ID)
      .order('last_seen', { ascending: false });

    if (error) Alert.alert('Supabase error', error.message);
    setDevices(devs || []);

    const nextLocations = {};
    for (const d of devs || []) {
      const { data } = await supabase
        .from('device_locations')
        .select('*')
        .eq('device_id', d.id)
        .order('recorded_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (data) nextLocations[d.id] = data;
    }
    setLocations(nextLocations);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    const timer = setInterval(load, 5000);
    return () => clearInterval(timer);
  }, [load]);

  const saveName = async () => {
    if (!selected || !newName.trim()) return;
    const { error } = await supabase.from('devices').update({ name: newName.trim() }).eq('id', selected.id);
    if (error) Alert.alert('Rename failed', error.message);
    setRenameOpen(false);
    setSelected({ ...selected, name: newName.trim() });
    load();
  };

  if (selected) {
    const loc = locations[selected.id];
    const live = isLive(selected.last_seen);
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar style="dark" />
        <Pressable onPress={() => setSelected(null)}><Text style={styles.back}>← Devices</Text></Pressable>
        <Text style={styles.title}>{selected.name}</Text>
        <Text style={live ? styles.live : styles.offline}>{live ? '● Live' : '● Offline'} · Last seen {selected.last_seen ? new Date(selected.last_seen).toLocaleTimeString() : 'Never'}</Text>
        <Pressable style={styles.button} onPress={() => { setNewName(selected.name); setRenameOpen(true); }}><Text style={styles.buttonText}>Rename device</Text></Pressable>
        <Text style={styles.section}>Map</Text>
        {loc ? (
          <MapView style={styles.map} initialRegion={{ latitude: loc.latitude, longitude: loc.longitude, latitudeDelta: 0.01, longitudeDelta: 0.01 }} region={{ latitude: loc.latitude, longitude: loc.longitude, latitudeDelta: 0.01, longitudeDelta: 0.01 }}>
            <Marker coordinate={{ latitude: loc.latitude, longitude: loc.longitude }} title={selected.name} description={`Accuracy ${Math.round(loc.accuracy || 0)}m`} />
          </MapView>
        ) : <View style={styles.empty}><Text>No location received yet.</Text></View>}
        <Text style={styles.small}>{loc ? `Lat ${loc.latitude.toFixed(6)}, Lng ${loc.longitude.toFixed(6)} · ${new Date(loc.recorded_at).toLocaleString()}` : ''}</Text>
        <Modal visible={renameOpen} transparent animationType="fade">
          <View style={styles.modalWrap}><View style={styles.modal}>
            <Text style={styles.section}>Rename device</Text>
            <TextInput value={newName} onChangeText={setNewName} style={styles.input} placeholder="Device name" />
            <Pressable style={styles.button} onPress={saveName}><Text style={styles.buttonText}>Save</Text></Pressable>
            <Pressable style={styles.ghost} onPress={() => setRenameOpen(false)}><Text>Cancel</Text></Pressable>
          </View></View>
        </Modal>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <Text style={styles.title}>Parent Monitor</Text>
      <Text style={styles.small}>Family: {FAMILY_ID}</Text>
      <FlatList
        refreshing={loading}
        onRefresh={load}
        data={devices}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<View style={styles.empty}><Text>No child devices connected yet.</Text></View>}
        renderItem={({ item }) => {
          const loc = locations[item.id];
          const live = isLive(item.last_seen);
          return <Pressable style={styles.card} onPress={() => setSelected(item)}>
            <Text style={styles.deviceName}>{item.name}</Text>
            <Text style={live ? styles.live : styles.offline}>{live ? '● Live' : '● Offline'}</Text>
            <Text style={styles.small}>{loc ? `Location: ${loc.latitude.toFixed(4)}, ${loc.longitude.toFixed(4)}` : 'No location yet'}</Text>
          </Pressable>;
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, backgroundColor: '#f7f8fb' },
  title: { fontSize: 30, fontWeight: '800', marginTop: 8, marginBottom: 8 },
  back: { fontSize: 17, marginTop: 10, marginBottom: 8, color: '#2563eb' },
  card: { backgroundColor: 'white', borderRadius: 16, padding: 16, marginTop: 12, borderWidth: 1, borderColor: '#e5e7eb' },
  deviceName: { fontSize: 20, fontWeight: '700' },
  live: { color: '#16a34a', fontWeight: '700', marginTop: 4 },
  offline: { color: '#dc2626', fontWeight: '700', marginTop: 4 },
  small: { color: '#64748b', marginTop: 6 },
  section: { fontSize: 20, fontWeight: '700', marginTop: 18, marginBottom: 10 },
  button: { backgroundColor: '#111827', padding: 14, borderRadius: 12, alignItems: 'center', marginTop: 14 },
  buttonText: { color: 'white', fontWeight: '700' },
  ghost: { padding: 14, alignItems: 'center' },
  map: { height: 360, borderRadius: 16, overflow: 'hidden' },
  empty: { padding: 24, backgroundColor: 'white', borderRadius: 16, alignItems: 'center', marginTop: 16 },
  modalWrap: { flex: 1, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'center', padding: 22 },
  modal: { backgroundColor: 'white', padding: 18, borderRadius: 18 },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 12, padding: 12, fontSize: 16 }
});
